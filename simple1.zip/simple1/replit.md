# Discord Self-Bot with Leveling System

## Overview
This is a Discord self-bot that provides automatic leveling functionality in a specific Discord channel. It uses the discord.js-selfbot-v13 library and sphinx-run for the leveling system.

## Project Structure
- `index.js` - Main bot file that initializes the Discord client and leveling system
- `package.json` - Node.js dependencies and project metadata
- `.gitignore` - Git ignore rules for node_modules and sensitive files

## Configuration
The bot requires the following environment variable:
- `DISCORD_TOKEN` - Your Discord account token for the self-bot

## Leveling Settings
Current configuration in index.js:
- Channel ID: `1436358636032102526`
- Random Letters: `false`
- Time Interval: `10000ms` (10 seconds)
- Type: `eng` (English)

## How to Run
1. Add your Discord token as a secret named `DISCORD_TOKEN`
2. The bot will start automatically via the workflow
3. Check the console logs to verify the bot is connected

## Dependencies
- `discord.js-selfbot-v13` - Discord self-bot library
- `sphinx-run` - Leveling system implementation

## Recent Changes
- November 10, 2025: Initial setup in Replit environment
  - Created package.json with required dependencies
  - Updated code to use environment variable for token
  - Configured workflow to run the bot
  - Added .gitignore for Node.js projects
